namespace UnityEngine.InputNew
{
	public delegate void FrameDelegate();
}
